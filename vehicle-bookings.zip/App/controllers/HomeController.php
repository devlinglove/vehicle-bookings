<?php

namespace App\Controllers;

use Framework\Database;

class HomeController
{
    protected Database $db;

    public function __construct()
    {
        $config = require basePath('config/db2.php');
        $this->db = new Database($config);
    }

    public function index()
    {
        //$listings = $this->db->query("SELECT * FROM listings LIMIT 6")->fetchAll();
        loadView('home');
    }

}
